# Retail Sales Lab

A Streamlit learning dashboard that explores fictional retail sales data with filters, metrics, charts, and tables.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `streamlit run main.py --server.address 0.0.0.0 --server.port ${REPLIT_PORT:-5000} --server.headless true` — run the retail sales dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- Python 3.13, Streamlit, Pandas, Plotly
- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `main.py` — Streamlit app and deterministic fictional dataset generator
- `pyproject.toml` / `uv.lock` — Python dependencies
- `artifacts/` — pre-existing API and mockup services, unrelated to the dashboard

## Architecture decisions

- The first version intentionally uses only deterministic, in-memory sample data.
- All visuals derive from the same filtered table to demonstrate the filter → calculate → group → visualize workflow.
- No upload, database, authentication, or external integrations are included.

## Product

- Interactive date, region, category, and channel filters
- Revenue, gross profit, units, and margin summary metrics
- Monthly trend and category charts
- Channel and region breakdowns
- Filtered fictional order table with CSV download

## User preferences

- Keep the first dashboard fully fictional so the user can learn before connecting real files.

## Gotchas

- Do not connect real business data unless explicitly requested in a later task.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
